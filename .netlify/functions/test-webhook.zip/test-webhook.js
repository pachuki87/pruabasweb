const axios = require('axios');

const WEBHOOK_URL = 'https://n8n.srv1024767.hstgr.cloud/webhook/fbdc5d15-3435-42f9-8047-891869aa9f7e';

exports.handler = async (event, context) => {
    try {
        console.log('Iniciando prueba de webhook...');

        const testPayload = {
            type: 'test',
            timestamp: new Date().toISOString(),
            message: 'Prueba de webhook desde Instituto Lidera',
            source: 'instituto-lidera-elearning',
            test: true
        };

        console.log('Enviando prueba a n8n:', JSON.stringify(testPayload, null, 2));

        const response = await axios.post(WEBHOOK_URL, testPayload, {
            headers: {
                'Content-Type': 'application/json',
                'User-Agent': 'Instituto-Lidera-Webhook-Test/1.0'
            },
            timeout: 15000
        });

        console.log('Respuesta de prueba:', response.status, response.data);

        return {
            statusCode: 200,
            body: JSON.stringify({
                success: true,
                message: 'Prueba de webhook exitosa',
                webhookResponse: response.data
            })
        };

    } catch (error) {
        console.error('Error en prueba de webhook:', error);

        return {
            statusCode: 500,
            body: JSON.stringify({
                success: false,
                error: error.message,
                details: error.response?.data || 'Error desconocido'
            })
        };
    }
};